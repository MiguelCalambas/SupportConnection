package Frames;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.PreparedStatement;
import javax.imageio.ImageIO;

public class RegistroInicial extends javax.swing.JFrame {
    
    FileInputStream archivofoto; 
    Connection conex;
    public RegistroInicial() {
        
        
        this.setVisible(true);
        this.getContentPane().setSize(965, 543);
        this.setTitle("Registro");
        initComponents();
        this.setLocationRelativeTo(null);
        
        
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        labelFoto = new javax.swing.JLabel();
        cBoxDocumento = new javax.swing.JComboBox<>();
        cBoxSangre = new javax.swing.JComboBox<>();
        txtNombre = new javax.swing.JTextField();
        txtDocumento = new javax.swing.JTextField();
        txtProblemas = new javax.swing.JTextField();
        btnContinuar = new javax.swing.JButton();
        txtAux = new javax.swing.JTextField();
        txtAux2 = new javax.swing.JTextField();
        txtRutaFoto = new javax.swing.JTextField();
        btnFoto = new javax.swing.JButton();
        gui = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(labelFoto, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 170, 170, 170));

        cBoxDocumento.setBackground(new java.awt.Color(204, 204, 204));
        cBoxDocumento.setForeground(new java.awt.Color(0, 0, 0));
        cBoxDocumento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Cédula de ciudadania ", "Cédula de extranjeria", "Tarjeta de identidad", "Pasaporte" }));
        cBoxDocumento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cBoxDocumentoActionPerformed(evt);
            }
        });
        jPanel1.add(cBoxDocumento, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 220, 210, 30));

        cBoxSangre.setBackground(new java.awt.Color(204, 204, 204));
        cBoxSangre.setForeground(new java.awt.Color(0, 0, 0));
        cBoxSangre.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "O+", "O-", "A+", "A-", "B+", "B-", "AB+", "AB-", " " }));
        cBoxSangre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cBoxSangreActionPerformed(evt);
            }
        });
        jPanel1.add(cBoxSangre, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 310, 210, 30));

        txtNombre.setBackground(new java.awt.Color(204, 204, 204));
        txtNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreActionPerformed(evt);
            }
        });
        txtNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtNombreKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNombreKeyTyped(evt);
            }
        });
        jPanel1.add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 180, 400, 30));

        txtDocumento.setBackground(new java.awt.Color(204, 204, 204));
        txtDocumento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDocumentoActionPerformed(evt);
            }
        });
        txtDocumento.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDocumentoKeyTyped(evt);
            }
        });
        jPanel1.add(txtDocumento, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 260, 260, 30));

        txtProblemas.setBackground(new java.awt.Color(204, 204, 204));
        jPanel1.add(txtProblemas, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 380, 570, 50));

        btnContinuar.setBorderPainted(false);
        btnContinuar.setContentAreaFilled(false);
        btnContinuar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnContinuarActionPerformed(evt);
            }
        });
        btnContinuar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                btnContinuarKeyReleased(evt);
            }
        });
        jPanel1.add(btnContinuar, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 450, 300, 80));

        txtAux.setEditable(false);
        txtAux.setOpaque(false);
        jPanel1.add(txtAux, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 320, 70, 20));

        txtAux2.setEditable(false);
        txtAux2.setOpaque(false);
        jPanel1.add(txtAux2, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 220, 70, 20));

        txtRutaFoto.setEditable(false);
        jPanel1.add(txtRutaFoto, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 350, 170, 20));

        btnFoto.setBorderPainted(false);
        btnFoto.setContentAreaFilled(false);
        btnFoto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFotoActionPerformed(evt);
            }
        });
        jPanel1.add(btnFoto, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 170, 170, 170));

        gui.setBackground(new java.awt.Color(204, 204, 204));
        gui.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Support Connection (2).png"))); // NOI18N
        jPanel1.add(gui, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnContinuarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnContinuarActionPerformed

            Conectar con = new Conectar();
            Connection cn=con.conexion();
            try{
            archivofoto = new FileInputStream(txtRutaFoto.getText());
            PreparedStatement ps= con.conexion().prepareStatement("INSERT INTO usuarios (nombre, tipo_doc, documento, tipo_san, problemas, foto, rutafoto)"
                                                                 +"VALUES (?,?,?,?,?,?,?)");
            
            archivofoto = new FileInputStream(txtRutaFoto.getText());
            ps.setString(1,txtNombre.getText());
            ps.setString(2,txtAux2.getText());
            ps.setString(3,txtDocumento.getText());
            ps.setString(4,txtAux.getText());
            ps.setString(5,txtProblemas.getText());
            ps.setBinaryStream(6,archivofoto);
            ps.setString(7,txtRutaFoto.getText());
            
            
            int i=ps.executeUpdate();
            if(i>0){
                JOptionPane.showMessageDialog(null, "Se guardo correctamente");
            }
             
             
            txtRutaFoto.setText(null);
            }catch(SQLException ex){
                
                Logger.getLogger(RegistroInicial.class.getName()).log(Level.SEVERE,null,ex);
                JOptionPane.showMessageDialog(null,"El proceso no se pudo realizar con exito","¡Ups!",JOptionPane.ERROR_MESSAGE);
                
            }catch (FileNotFoundException ex) {
                Logger.getLogger(RegistroInicial.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null,"El proceso no se pudo realizar con exito","¡Ups!",JOptionPane.ERROR_MESSAGE);
            } 
            
            Inicio IN = new Inicio();
            this.setVisible(false);
            IN.setVisible(true);
    }//GEN-LAST:event_btnContinuarActionPerformed

    private void cBoxSangreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cBoxSangreActionPerformed
        
        String selectedValue = cBoxSangre.getSelectedItem().toString();
        txtAux.setText(selectedValue);
    }//GEN-LAST:event_cBoxSangreActionPerformed

    private void cBoxDocumentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cBoxDocumentoActionPerformed
        String selectedValue = cBoxDocumento.getSelectedItem().toString();
        txtAux2.setText(selectedValue);
    }//GEN-LAST:event_cBoxDocumentoActionPerformed

    private void btnFotoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFotoActionPerformed
        JFileChooser archivo=new JFileChooser();
        archivo.showOpenDialog(null);
        File f = archivo.getSelectedFile();
        String ruta= f.getAbsolutePath();
        txtRutaFoto.setText(String.valueOf(f));
        
        try {
            BufferedImage bi = ImageIO.read(new File(ruta));
            Image img = bi.getScaledInstance(172,174,Image.SCALE_SMOOTH);
            ImageIcon icon = new ImageIcon(img);
            labelFoto.setIcon(icon);
            
        } catch (IOException ex) {
            Logger.getLogger(RegistroInicial.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnFotoActionPerformed

    private void btnContinuarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btnContinuarKeyReleased
        
        
    }//GEN-LAST:event_btnContinuarKeyReleased

    private void txtNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreActionPerformed

    private void txtNombreKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombreKeyReleased
       
        
    }//GEN-LAST:event_txtNombreKeyReleased

    private void txtDocumentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDocumentoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDocumentoActionPerformed

    private void txtDocumentoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDocumentoKeyTyped
        char c = evt.getKeyChar();
        
        if(!Character.isDigit(c)){
            evt.consume();  
        }
    }//GEN-LAST:event_txtDocumentoKeyTyped

    private void txtNombreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombreKeyTyped
        char c = evt.getKeyChar();
        
        if(Character.isLetter(c) || Character.isWhitespace(c) || Character.isISOControl(c)){
            txtNombre.setEditable(true);
        }else{
            txtNombre.setEditable(false);
        }
    }//GEN-LAST:event_txtNombreKeyTyped

    public static void main(String args[]) {
        
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegistroInicial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegistroInicial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegistroInicial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegistroInicial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegistroInicial().setVisible(true);
            }
        });
    }
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnContinuar;
    private javax.swing.JButton btnFoto;
    private javax.swing.JComboBox<String> cBoxDocumento;
    private javax.swing.JComboBox<String> cBoxSangre;
    private javax.swing.JLabel gui;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel labelFoto;
    private javax.swing.JTextField txtAux;
    private javax.swing.JTextField txtAux2;
    private javax.swing.JTextField txtDocumento;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtProblemas;
    private javax.swing.JTextField txtRutaFoto;
    // End of variables declaration//GEN-END:variables
}
