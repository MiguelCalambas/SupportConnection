/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FramesAdministrador;

import Frames.Conectar;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Blob;
import java.io.FileOutputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.imageio.ImageIO;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class ListaAlertas extends javax.swing.JFrame {

    Connection conex;
    Conectar ce= new Conectar();
    DefaultTableModel modelo;
    Statement st;
    ResultSet rs,rss;
    int idc;
    
    public ListaAlertas() {
        initComponents();
        this.setLocationRelativeTo(null);
        listar();
        
    }
    
    void listar(){
        String sql="select * from usuarios";
        
        try{
            conex= ce.conexion();
            
            st= conex.createStatement();
            rs= st.executeQuery(sql);
            
            
            Object[] usuarioo = new Object[7];
            
            modelo=(DefaultTableModel) Tabla.getModel();
            
            
            while(rs.next()){
                usuarioo[0]=rs.getString("nombre");
                usuarioo[1]=rs.getString("tipo_doc");
                usuarioo[2]=rs.getInt("documento");
                usuarioo[3]=rs.getString("tipo_san");
                usuarioo[4]=rs.getString("problemas");
                usuarioo[5]=new ImageIcon(rs.getBytes("foto"));
                usuarioo[6]=rs.getString("rutafoto");
     
                modelo.addRow(usuarioo);
            }
            
            
            
            
            Tabla.setModel(modelo);
        }catch(Exception e){
            
        }
        
    }
   

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txtBusqueda = new javax.swing.JTextField();
        BtnBuscar = new javax.swing.JButton();
        txtNombre = new javax.swing.JTextField();
        txtTipoDocumento = new javax.swing.JTextField();
        txtDocumento = new javax.swing.JTextField();
        txtTipoSangre = new javax.swing.JTextField();
        txtProblemas = new javax.swing.JTextField();
        Foto = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Tabla = new javax.swing.JTable();
        BtnMapa = new javax.swing.JButton();
        BtnVolver = new javax.swing.JButton();
        fondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtBusqueda.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jPanel1.add(txtBusqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, 760, 40));

        BtnBuscar.setForeground(new java.awt.Color(0, 0, 0));
        BtnBuscar.setBorderPainted(false);
        BtnBuscar.setContentAreaFilled(false);
        BtnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnBuscarActionPerformed(evt);
            }
        });
        jPanel1.add(BtnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 200, 70, 40));

        txtNombre.setEditable(false);
        txtNombre.setBackground(new java.awt.Color(204, 204, 204));
        txtNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreActionPerformed(evt);
            }
        });
        txtNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtNombreKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNombreKeyTyped(evt);
            }
        });
        jPanel1.add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 350, 400, 30));

        txtTipoDocumento.setEditable(false);
        txtTipoDocumento.setBackground(new java.awt.Color(204, 204, 204));
        txtTipoDocumento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTipoDocumentoActionPerformed(evt);
            }
        });
        txtTipoDocumento.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtTipoDocumentoKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtTipoDocumentoKeyTyped(evt);
            }
        });
        jPanel1.add(txtTipoDocumento, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 390, 400, 30));

        txtDocumento.setEditable(false);
        txtDocumento.setBackground(new java.awt.Color(204, 204, 204));
        txtDocumento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDocumentoActionPerformed(evt);
            }
        });
        txtDocumento.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtDocumentoKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDocumentoKeyTyped(evt);
            }
        });
        jPanel1.add(txtDocumento, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 430, 400, 30));

        txtTipoSangre.setEditable(false);
        txtTipoSangre.setBackground(new java.awt.Color(204, 204, 204));
        txtTipoSangre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTipoSangreActionPerformed(evt);
            }
        });
        txtTipoSangre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtTipoSangreKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtTipoSangreKeyTyped(evt);
            }
        });
        jPanel1.add(txtTipoSangre, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 470, 400, 30));

        txtProblemas.setEditable(false);
        txtProblemas.setBackground(new java.awt.Color(204, 204, 204));
        txtProblemas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtProblemasActionPerformed(evt);
            }
        });
        txtProblemas.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtProblemasKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtProblemasKeyTyped(evt);
            }
        });
        jPanel1.add(txtProblemas, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 510, 400, 30));
        jPanel1.add(Foto, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 360, 150, 170));

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "Tipo de documento", "N°Documento", "Tipo de sangre", "Problemas", "Foto", "RutaFoto"
            }
        ));
        Tabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TablaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(Tabla);

        jPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 830, 90));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 250, 830, 90));

        BtnMapa.setBackground(new java.awt.Color(255, 255, 255));
        BtnMapa.setForeground(new java.awt.Color(0, 0, 0));
        BtnMapa.setText("Ver en mapa");
        BtnMapa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnMapaActionPerformed(evt);
            }
        });
        jPanel1.add(BtnMapa, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 490, 120, 50));

        BtnVolver.setBackground(new java.awt.Color(244, 244, 244));
        BtnVolver.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        BtnVolver.setForeground(new java.awt.Color(0, 0, 0));
        BtnVolver.setText("Volver");
        BtnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnVolverActionPerformed(evt);
            }
        });
        jPanel1.add(BtnVolver, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, 90, 60));

        fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Tipo.Doc.png"))); // NOI18N
        jPanel1.add(fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    private void BtnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnBuscarActionPerformed
        
    }//GEN-LAST:event_BtnBuscarActionPerformed

    private void txtProblemasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtProblemasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtProblemasActionPerformed

    private void txtProblemasKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtProblemasKeyReleased

    }//GEN-LAST:event_txtProblemasKeyReleased

    private void txtProblemasKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtProblemasKeyTyped
        char c = evt.getKeyChar();

        if(Character.isLetter(c) || Character.isWhitespace(c) || Character.isISOControl(c)){
            txtProblemas.setEditable(true);
        }else{
            txtProblemas.setEditable(false);
        }
    }//GEN-LAST:event_txtProblemasKeyTyped

    private void txtNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreActionPerformed

    private void txtNombreKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombreKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreKeyReleased

    private void txtNombreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombreKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreKeyTyped

    private void txtTipoDocumentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTipoDocumentoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTipoDocumentoActionPerformed

    private void txtTipoDocumentoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTipoDocumentoKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTipoDocumentoKeyReleased

    private void txtTipoDocumentoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTipoDocumentoKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTipoDocumentoKeyTyped

    private void txtDocumentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDocumentoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDocumentoActionPerformed

    private void txtDocumentoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDocumentoKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDocumentoKeyReleased

    private void txtDocumentoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDocumentoKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDocumentoKeyTyped

    private void txtTipoSangreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTipoSangreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTipoSangreActionPerformed

    private void txtTipoSangreKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTipoSangreKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTipoSangreKeyReleased

    private void txtTipoSangreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTipoSangreKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTipoSangreKeyTyped

    
    
    private void TablaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TablaMouseClicked
        int rowIndex=Tabla.getSelectedRow();
        int columnIndex=Tabla.getSelectedColumn();
        

        TableModel model= Tabla.getModel();
        txtNombre.setText(model.getValueAt(rowIndex,0).toString());
        txtTipoDocumento.setText(model.getValueAt(rowIndex,1).toString());
        txtDocumento.setText(model.getValueAt(rowIndex,2).toString());
        txtTipoSangre.setText(model.getValueAt(rowIndex,3).toString());
        txtProblemas.setText(model.getValueAt(rowIndex,4).toString());
    }//GEN-LAST:event_TablaMouseClicked

    private void BtnMapaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnMapaActionPerformed
        Mapa MA = new Mapa();
        MA.setVisible(true);
    }//GEN-LAST:event_BtnMapaActionPerformed

    private void BtnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnVolverActionPerformed
        InicioAdmin IA = new InicioAdmin();
        this.setVisible(false);
        IA.setVisible(true);
    }//GEN-LAST:event_BtnVolverActionPerformed


    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ListaAlertas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ListaAlertas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ListaAlertas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ListaAlertas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ListaAlertas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnBuscar;
    private javax.swing.JButton BtnMapa;
    private javax.swing.JButton BtnVolver;
    private javax.swing.JLabel Foto;
    private javax.swing.JTable Tabla;
    private javax.swing.JLabel fondo;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtBusqueda;
    private javax.swing.JTextField txtDocumento;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtProblemas;
    private javax.swing.JTextField txtTipoDocumento;
    private javax.swing.JTextField txtTipoSangre;
    // End of variables declaration//GEN-END:variables

    private Icon Icon(int rowIndex, int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
